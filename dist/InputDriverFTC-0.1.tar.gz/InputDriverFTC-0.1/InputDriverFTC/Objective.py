from collections import namedtuple

Objective = namedtuple("Objective", 'name,objective_type,x,y')
